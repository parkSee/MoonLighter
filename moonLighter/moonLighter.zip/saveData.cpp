#include "stdafx.h"
#include "saveData.h"


HRESULT saveData::init()
{
	return S_OK;
}

void saveData::release()
{
}
