#include "stdafx.h"
#include "stone.h"


HRESULT stone::init(string _objName, tagFloat _pos, image * imgName)
{
	return S_OK;
}

void stone::release()
{
}

void stone::update()
{
}

void stone::render()
{
}

stone::stone()
{
}


stone::~stone()
{
}
