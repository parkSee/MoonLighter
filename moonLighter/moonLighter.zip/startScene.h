#pragma once
#include "gameNode.h"

class startScene : public gameNode
{
public:
	startScene();
	~startScene();
};

