#include "stdafx.h"
#include "loadingScene.h"


void loadingScene::lejImageLoading()
{


}
