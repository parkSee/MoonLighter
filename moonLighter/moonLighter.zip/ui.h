#pragma once
class ui
{
public:
	ui(){}
	~ui(){}
};

