#include "stdafx.h"
#include "item.h"

HRESULT item::init()
{	
	
	return S_OK;
}

void item::release()
{
}

void item::update()
{
	
}

void item::render()
{	

}
